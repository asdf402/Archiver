﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Archiver
{
    public class ParsedArguments
    {
        public bool HasCreate
        {
            get => default;
            set
            {
            }
        }

        public bool HasAppend
        {
            get => default;
            set
            {
            }
        }

        public bool HasExtract
        {
            get => default;
            set
            {
            }
        }

        public bool HasRleCompress
        {
            get => default;
            set
            {
            }
        }

        public bool HasInfo
        {
            get => default;
            set
            {
            }
        }

        public bool HasList
        {
            get => default;
            set
            {
            }
        }

        public bool HasRetry
        {
            get => default;
            set
            {
            }
        }

        public bool HasWait
        {
            get => default;
            set
            {
            }
        }

        public bool HasSource
        {
            get => default;
            set
            {
            }
        }

        public bool HasDestination
        {
            get => default;
            set
            {
            }
        }

        public ulong RetryAmount
        {
            get => default;
            set
            {
            }
        }

        public DateTime WaitTime
        {
            get => default;
            set
            {
            }
        }

        public string Source
        {
            get => default;
            set
            {
            }
        }

        public string Destination
        {
            get => default;
            set
            {
            }
        }
    }
}