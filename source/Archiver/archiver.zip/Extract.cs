﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Archiver
{
    public class Extract : Commands
    {
        public void Execute()
        {
            throw new NotImplementedException();
        }
    }
}